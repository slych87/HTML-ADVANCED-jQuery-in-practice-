
// const paragraphText = $('p').text();
// console.log(paragraphText);
// $('p:nth-of-type(2)').text("nowy tekst");
// $('html').html();
// $('section').html();
// $('p:nth-of-type(1)').html();
// $('p:nth-of-type(1)').text();


/* Tworzenie elementu */

const $titleH1 = $('<h1 class="red">Tytuł artykułu</h1>');
// $('div').before($titleH1);
// $('div').after($titleH1);
// $('div').prepend($titleH1);
// $('div').append($titleH1);
// $titleH1.prependTo('div');
// $titleH1.appendTo('div');

// Nie zadziała JavaScript
// document.body.appendChild($titleH1);


