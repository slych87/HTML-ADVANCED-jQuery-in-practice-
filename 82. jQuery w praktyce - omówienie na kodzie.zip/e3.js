// $('div.item1').attr("class");
// const divClass = $('div.item1').attr("class");
// console.log(divClass);

// $('div.item1').attr("class", "red blue");

// console.log($('div.red.blue').attr("class"));
// console.log($('div.red').attr("class"));

console.log($('[data-idUser]').attr("id"));

// $('[data-idUser]').attr("id", "");

// console.log($('[data-idUser]').attr("id"));

console.log($('.vip_user').removeAttr("class"));